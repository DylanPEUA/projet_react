import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Bonjour, je suis John Doe</h1>
      <h2>Developpeur Web Fullstack</h2>
      <img
        src="
        "
        alt="The head and torso of a dinosaur skeleton;
          it has a large head with long sharp teeth"
      />
    </div>
  );
}
